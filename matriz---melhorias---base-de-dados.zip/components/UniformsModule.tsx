
import React from 'react';

const UniformsModule: React.FC = () => {
    return (
        <div>
            <h2>Uniforms Module</h2>
            <p>This feature is under development.</p>
        </div>
    );
};

export default UniformsModule;
