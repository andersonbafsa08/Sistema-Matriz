
import React from 'react';

const FinancialSettingsForm: React.FC = () => {
    return (
        <div>
            <h3>Financial Settings</h3>
            <p>This feature is under development.</p>
        </div>
    );
};

export default FinancialSettingsForm;
