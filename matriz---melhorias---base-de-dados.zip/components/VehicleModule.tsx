
import React from 'react';

const VehicleModule: React.FC = () => {
    return (
        <div>
            <h2>Vehicle Module</h2>
            <p>This feature is under development.</p>
        </div>
    );
};

export default VehicleModule;
