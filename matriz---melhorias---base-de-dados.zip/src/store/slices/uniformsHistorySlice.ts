
import { createSlice } from '@reduxjs/toolkit';

const uniformsHistorySlice = createSlice({
    name: 'uniformsHistory_placeholder',
    initialState: {},
    reducers: {},
});

export default uniformsHistorySlice.reducer;
