
import { createSlice } from '@reduxjs/toolkit';

const uniformsSettingsSlice = createSlice({
    name: 'uniformsSettings_placeholder',
    initialState: {},
    reducers: {},
});

export default uniformsSettingsSlice.reducer;
