
import { createSlice } from '@reduxjs/toolkit';

const uniformsStockSlice = createSlice({
    name: 'uniformsStock_placeholder',
    initialState: {},
    reducers: {},
});

export default uniformsStockSlice.reducer;
